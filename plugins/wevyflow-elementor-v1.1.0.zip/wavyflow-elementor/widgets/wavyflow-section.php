<?php
namespace WavyFlow\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class WavyFlow_Section extends Widget_Base {
    public function get_name() { return 'wf-section'; }
    public function get_title() { return 'WavyFlow Section'; }
    public function get_icon() { return 'eicon-code'; }
    public function get_categories() { return ['wavyflow']; }
    public function get_keywords() { return ['wavyflow', 'section', 'html', 'template']; }

    protected function register_controls() {
        // ─── HTML Original (hidden in normal use, stores the source) ───
        $this->start_controls_section('source_section', [
            'label' => 'Codigo Fonte',
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('original_html', [
            'label' => 'HTML Original',
            'type' => Controls_Manager::TEXTAREA,
            'default' => '',
            'description' => 'Codigo HTML original da secao. Gerado automaticamente pelo WavyFlow.',
            'rows' => 6,
        ]);
        $this->add_control('section_label', [
            'label' => 'Nome da secao',
            'type' => Controls_Manager::TEXT,
            'default' => 'Secao WavyFlow',
        ]);
        $this->end_controls_section();

        // ─── Editable Fields (auto-extracted) ───
        $this->start_controls_section('text_section', [
            'label' => 'Textos',
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('edit_headline', [
            'label' => 'Headline',
            'type' => Controls_Manager::TEXTAREA,
            'default' => '',
            'description' => 'Titulo principal (h1 ou h2). Deixe vazio para manter o original.',
            'rows' => 3,
        ]);
        $this->add_control('edit_subtitle', [
            'label' => 'Subtitulo',
            'type' => Controls_Manager::TEXTAREA,
            'default' => '',
            'description' => 'Paragrafo principal. Deixe vazio para manter o original.',
            'rows' => 3,
        ]);
        $this->add_control('edit_paragraph_2', [
            'label' => 'Paragrafo 2',
            'type' => Controls_Manager::TEXTAREA,
            'default' => '',
            'description' => 'Segundo paragrafo (se existir). Deixe vazio para manter o original.',
            'rows' => 3,
        ]);
        $this->end_controls_section();

        // ─── CTA ───
        $this->start_controls_section('cta_section', [
            'label' => 'Botao CTA',
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('edit_cta_text', [
            'label' => 'Texto do botao',
            'type' => Controls_Manager::TEXT,
            'default' => '',
            'description' => 'Deixe vazio para manter o original.',
        ]);
        $this->add_control('edit_cta_url', [
            'label' => 'Link do botao',
            'type' => Controls_Manager::URL,
            'default' => ['url' => ''],
            'description' => 'Deixe vazio para manter o original.',
        ]);
        $this->end_controls_section();

        // ─── Image ───
        $this->start_controls_section('image_section', [
            'label' => 'Imagem',
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('edit_image', [
            'label' => 'Imagem principal',
            'type' => Controls_Manager::MEDIA,
            'description' => 'Substitui o placeholder ou imagem existente na secao.',
        ]);
        $this->end_controls_section();

        // ─── Videos (YouTube / VTurb) ───
        $this->start_controls_section('videos_section', [
            'label' => 'Videos',
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);
        for ($i = 1; $i <= 3; $i++) {
            $this->add_control("edit_video_{$i}_id", [
                'label' => "Video {$i} - ID / Codigo",
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'description' => "Cole o ID do YouTube (ex: dQw4w9WgXcQ) ou do player VTurb. Deixe vazio para manter o original.",
            ]);
            $this->add_control("edit_video_{$i}_type", [
                'label' => "Video {$i} - Tipo",
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => 'Manter original',
                    'youtube' => 'YouTube',
                    'vturb' => 'VTurb',
                ],
            ]);
        }
        $this->end_controls_section();

        // ─── Original Values (auto-populated, hidden) ───
        $this->start_controls_section('originals_section', [
            'label' => 'Valores Originais (auto)',
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('orig_headline', [
            'label' => 'Headline original',
            'type' => Controls_Manager::HIDDEN,
            'default' => '',
        ]);
        $this->add_control('orig_subtitle', [
            'label' => 'Subtitulo original',
            'type' => Controls_Manager::HIDDEN,
            'default' => '',
        ]);
        $this->add_control('orig_paragraph_2', [
            'label' => 'Paragrafo 2 original',
            'type' => Controls_Manager::HIDDEN,
            'default' => '',
        ]);
        $this->add_control('orig_cta_text', [
            'label' => 'CTA original',
            'type' => Controls_Manager::HIDDEN,
            'default' => '',
        ]);
        $this->add_control('orig_cta_url', [
            'label' => 'CTA URL original',
            'type' => Controls_Manager::HIDDEN,
            'default' => '',
        ]);
        for ($i = 1; $i <= 3; $i++) {
            $this->add_control("orig_video_{$i}_id", [
                'label' => "Video {$i} ID original",
                'type' => Controls_Manager::HIDDEN,
                'default' => '',
            ]);
            $this->add_control("orig_video_{$i}_type", [
                'label' => "Video {$i} tipo original",
                'type' => Controls_Manager::HIDDEN,
                'default' => '',
            ]);
        }
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $html = $s['original_html'] ?? '';

        if (empty($html)) {
            if (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
                echo '<div style="padding:40px;text-align:center;background:#1e1e1e;border-radius:12px;color:#888;font-family:sans-serif;">';
                echo '<p style="font-size:14px;margin-bottom:8px;">WavyFlow Section</p>';
                echo '<p style="font-size:11px;color:#555;">Cole o HTML da secao no campo "Codigo Fonte"</p>';
                echo '</div>';
            }
            return;
        }

        // Apply text replacements
        $output = $html;

        // Headline replacement
        $new_headline = trim($s['edit_headline'] ?? '');
        $orig_headline = trim($s['orig_headline'] ?? '');
        if ($new_headline !== '' && $orig_headline !== '' && $new_headline !== $orig_headline) {
            $output = str_replace($orig_headline, $new_headline, $output);
        }

        // Subtitle replacement
        $new_subtitle = trim($s['edit_subtitle'] ?? '');
        $orig_subtitle = trim($s['orig_subtitle'] ?? '');
        if ($new_subtitle !== '' && $orig_subtitle !== '' && $new_subtitle !== $orig_subtitle) {
            $output = str_replace($orig_subtitle, $new_subtitle, $output);
        }

        // Paragraph 2 replacement
        $new_p2 = trim($s['edit_paragraph_2'] ?? '');
        $orig_p2 = trim($s['orig_paragraph_2'] ?? '');
        if ($new_p2 !== '' && $orig_p2 !== '' && $new_p2 !== $orig_p2) {
            $output = str_replace($orig_p2, $new_p2, $output);
        }

        // CTA text replacement
        $new_cta = trim($s['edit_cta_text'] ?? '');
        $orig_cta = trim($s['orig_cta_text'] ?? '');
        if ($new_cta !== '' && $orig_cta !== '' && $new_cta !== $orig_cta) {
            $output = str_replace($orig_cta, $new_cta, $output);
        }

        // CTA URL replacement
        $cta_url = $s['edit_cta_url'] ?? [];
        $new_url = is_array($cta_url) ? trim($cta_url['url'] ?? '') : '';
        $orig_url = trim($s['orig_cta_url'] ?? '');
        if ($new_url !== '' && $orig_url !== '' && $new_url !== $orig_url) {
            $output = str_replace('href="' . $orig_url . '"', 'href="' . esc_url($new_url) . '"', $output);
        }

        // Video replacement (YouTube / VTurb) — swaps the ID (and type if it changed)
        // The ID appears in multiple places (data-wf-video, iframe src, id="vid_XYZ",
        // thumbnail URL, player script URL), so a single str_replace propagates everywhere.
        for ($i = 1; $i <= 3; $i++) {
            $orig_id   = trim($s["orig_video_{$i}_id"] ?? '');
            $orig_type = trim($s["orig_video_{$i}_type"] ?? '');
            $new_id    = trim($s["edit_video_{$i}_id"] ?? '');
            $new_type  = trim($s["edit_video_{$i}_type"] ?? '');
            if ($orig_id === '') continue;

            // If user only changed the type (kept same slot), use the original ID
            $target_id = $new_id !== '' ? $new_id : $orig_id;
            $target_type = $new_type !== '' ? $new_type : $orig_type;

            // Same type → simple ID swap across the whole markup
            if ($target_type === $orig_type) {
                if ($target_id !== $orig_id) {
                    $output = str_replace($orig_id, $target_id, $output);
                }
                continue;
            }

            // Type changed → rebuild the entire video block
            $pattern = '/<div[^>]*data-wf-video="' . preg_quote($orig_type, '/') . ':' . preg_quote($orig_id, '/') . '"[^>]*>[\s\S]*?<\/div>(?:\s*<script[^>]*>[\s\S]*?<\/script>)?/i';

            if ($target_type === 'youtube') {
                $replacement = '<div class="reveal" data-wf-video="youtube:' . esc_attr($target_id) . '" style="position:relative;width:100%;padding-top:56.25%;border-radius:12px;overflow:hidden">'
                    . '<iframe src="https://www.youtube.com/embed/' . esc_attr($target_id) . '" style="position:absolute;inset:0;width:100%;height:100%;border:0" allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture" allowfullscreen></iframe>'
                    . '</div>';
            } elseif ($target_type === 'vturb') {
                $replacement = '<div class="reveal" data-wf-video="vturb:' . esc_attr($target_id) . '" id="vid_' . esc_attr($target_id) . '" style="position:relative;width:100%;padding-top:56.25%">'
                    . '<img id="thumb_' . esc_attr($target_id) . '" src="https://images.converteai.net/' . esc_attr($target_id) . '/players/' . esc_attr($target_id) . '/thumbnail.jpg" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block" alt="thumbnail">'
                    . '</div>'
                    . '<script type="text/javascript">var s=document.createElement("script");s.src="https://scripts.converteai.net/' . esc_attr($target_id) . '/players/' . esc_attr($target_id) . '/player.js";s.async=true;document.head.appendChild(s);</script>';
            } else {
                continue;
            }

            $output = preg_replace($pattern, $replacement, $output, 1);
        }

        // Image replacement — replace placeholder div with actual image
        $img = $s['edit_image'] ?? [];
        $img_url = is_array($img) ? ($img['url'] ?? '') : '';
        if ($img_url !== '') {
            $img_tag = '<img src="' . esc_url($img_url) . '" alt="" style="width:100%;height:100%;object-fit:cover;object-position:center 20%;border-radius:inherit;">';
            // Replace ph (placeholder) — uses (?s) flag for dot-matches-newline
            $output = preg_replace(
                '/(?s)<div class="ph">.*?<\/div>\s*<\/div>\s*<\/div>/',
                $img_tag,
                $output,
                1
            );
            // Replace hero-video placeholder
            $output = preg_replace(
                '/(?s)<div class="hero-video-placeholder">.*?<\/div>\s*<\/div>/',
                $img_tag,
                $output,
                1
            );
            // Replace hero-video container itself
            $output = preg_replace(
                '/(?s)<div class="hero-video">.*?<\/div>\s*<\/div>\s*<\/div>/',
                '<div class="hero-video" style="display:flex;align-items:center;justify-content:center;overflow:hidden;">' . $img_tag . '</div>',
                $output,
                1
            );
        }

        // Wrap in .wfr scope to increase CSS specificity over Elementor theme
        echo '<div class="wfr">' . $output . '</div>';
    }
}
