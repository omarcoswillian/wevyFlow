<?php
namespace WavyFlow\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

/**
 * wf-shared-styles
 * Invisible widget that carries the template's shared stylesheet and font <link>s.
 * The payload is split in two controls so CSS travels as plain text (less chance of
 * being stripped by wp_kses) and the <link> tags are kept intact for Google Fonts.
 *
 * The plugin also scans every post's _elementor_data at wp_head time (see
 * wavyflow_inject_shared_css()) and injects the contents directly into <head>,
 * bypassing this widget's own render path for maximum robustness.
 */
class WF_Shared_Styles extends Widget_Base {
    public function get_name()       { return 'wf-shared-styles'; }
    public function get_title()      { return 'WavyFlow Shared Styles'; }
    public function get_icon()       { return 'eicon-code'; }
    public function get_categories() { return ['wavyflow']; }
    public function get_keywords()   { return ['wavyflow', 'styles', 'css']; }

    protected function register_controls() {
        $this->start_controls_section('source', [
            'label' => 'Estilos (auto)',
            'tab'   => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('shared_fonts', [
            'label'       => 'Links de fontes',
            'type'        => Controls_Manager::CODE,
            'language'    => 'html',
            'default'     => '',
            'rows'        => 4,
            'description' => 'Tags <link> para Google Fonts. Preenchido automaticamente.',
        ]);

        $this->add_control('shared_css', [
            'label'       => 'CSS compartilhado',
            'type'        => Controls_Manager::CODE,
            'language'    => 'css',
            'default'     => '',
            'rows'        => 20,
            'description' => 'CSS da landing page. Preenchido automaticamente pelo export.',
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $s     = $this->get_settings_for_display();
        $css   = $s['shared_css']   ?? '';
        $fonts = $s['shared_fonts'] ?? '';

        $css_decoded   = html_entity_decode($css,   ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $fonts_decoded = html_entity_decode($fonts, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        if ($css_decoded === '' && $fonts_decoded === '') {
            if (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
                echo '<div style="padding:16px;background:#1e1e1e;border-radius:8px;color:#888;font:12px sans-serif;text-align:center;">WavyFlow Shared Styles (invisivel no front-end)</div>';
            }
            return;
        }

        if ($fonts_decoded !== '') {
            echo $fonts_decoded;
        }
        if ($css_decoded !== '') {
            echo '<style id="wavyflow-shared-widget">' . $css_decoded . '</style>';
        }
    }
}
