<?php
namespace WavyFlow\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

/**
 * wf-shared-styles
 * Invisible widget whose sole job is to print the template's shared <style> block
 * once, at the top of the exported page. Every other WavyFlow widget relies on
 * those classes (.block, .hero, .urgency, .pix-word, …) for their visual styling
 * — the native Elementor widgets that the export produces just carry the class
 * names via _css_classes.
 */
class WF_Shared_Styles extends Widget_Base {
    public function get_name()       { return 'wf-shared-styles'; }
    public function get_title()      { return 'WavyFlow Shared Styles'; }
    public function get_icon()       { return 'eicon-code'; }
    public function get_categories() { return ['wavyflow']; }
    public function get_keywords()   { return ['wavyflow', 'styles', 'css']; }

    protected function register_controls() {
        $this->start_controls_section('source', [
            'label' => 'Estilos (auto)',
            'tab'   => Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('shared_css', [
            'label'       => 'CSS compartilhado',
            'type'        => Controls_Manager::TEXTAREA,
            'default'     => '',
            'rows'        => 8,
            'description' => 'CSS compartilhado da landing page. Preenchido automaticamente pelo export.',
        ]);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $css = $s['shared_css'] ?? '';
        if (!empty($css)) {
            // CSS may already contain <style>..</style> and <link> (Google Fonts).
            // Print verbatim — the export is responsible for the content.
            echo $css;
        } elseif (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
            echo '<div style="padding:16px;background:#1e1e1e;border-radius:8px;color:#888;font:12px sans-serif;text-align:center;">WavyFlow Shared Styles (invisivel no front-end)</div>';
        }
    }
}
