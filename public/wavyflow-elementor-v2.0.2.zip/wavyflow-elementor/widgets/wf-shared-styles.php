<?php
namespace WavyFlow\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

/**
 * wf-shared-styles
 * Carries the template's shared stylesheet + font links. Payload is base64-encoded
 * on export so it survives wp_kses sanitization unchanged (only A-Z 0-9 +/= chars).
 *
 * Two rendering paths:
 *   1. render() — prints <style>/<link> inside <body> when the widget itself draws.
 *   2. wavyflow_inject_shared_css() — scans _elementor_data on wp_head and prints
 *      into <head>, the preferred path for real page loads.
 */
class WF_Shared_Styles extends Widget_Base {
    public function get_name()       { return 'wf-shared-styles'; }
    public function get_title()      { return 'WavyFlow Shared Styles'; }
    public function get_icon()       { return 'eicon-code'; }
    public function get_categories() { return ['wavyflow']; }
    public function get_keywords()   { return ['wavyflow', 'styles', 'css']; }

    protected function register_controls() {
        $this->start_controls_section('source', [
            'label' => 'Estilos (auto)',
            'tab'   => Controls_Manager::TAB_CONTENT,
        ]);

        // Base64-encoded payload — the fields actually used at render time.
        // TEXTAREA is fine for base64 because the chars (A-Za-z0-9+/=) pass wp_kses untouched.
        $this->add_control('shared_fonts_b64', [
            'label'       => 'Fontes (base64)',
            'type'        => Controls_Manager::TEXTAREA,
            'default'     => '',
            'rows'        => 3,
            'description' => 'Tags <link> base64-encoded. Preenchido pelo export.',
        ]);

        $this->add_control('shared_css_b64', [
            'label'       => 'CSS (base64)',
            'type'        => Controls_Manager::TEXTAREA,
            'default'     => '',
            'rows'        => 8,
            'description' => 'CSS base64-encoded. Preenchido pelo export.',
        ]);

        // Readable copies (not used at render) — only for the user to inspect.
        $this->add_control('shared_css', [
            'label'       => 'CSS (leitura)',
            'type'        => Controls_Manager::CODE,
            'language'    => 'css',
            'default'     => '',
            'rows'        => 12,
            'description' => 'Apenas para leitura. Nao editado.',
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();

        $css_b64   = trim($s['shared_css_b64']   ?? '');
        $fonts_b64 = trim($s['shared_fonts_b64'] ?? '');

        $css   = $css_b64   !== '' ? base64_decode($css_b64, true)   : '';
        $fonts = $fonts_b64 !== '' ? base64_decode($fonts_b64, true) : '';

        if ($css === false) $css = '';
        if ($fonts === false) $fonts = '';

        if ($css === '' && $fonts === '') {
            if (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
                echo '<div style="padding:16px;background:#1e1e1e;border-radius:8px;color:#888;font:12px sans-serif;text-align:center;">WavyFlow Shared Styles (invisivel no front-end)</div>';
            }
            return;
        }

        if ($fonts !== '') {
            echo $fonts;
        }
        if ($css !== '') {
            echo '<style id="wavyflow-shared-widget">' . $css . '</style>';
        }
    }
}
